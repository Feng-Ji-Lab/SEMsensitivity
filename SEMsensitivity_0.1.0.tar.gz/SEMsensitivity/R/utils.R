

options(warn = -1)
.SEMClusterEnv <- new.env(parent=emptyenv())
utils::globalVariables(c(".", ".data"))

